package com.example.justquotes;

public class Quote {

    private String quoteId;
    private String quoteText;
    private String quoteLang;
    private String quoteWriter;
    private String quoteLikes;
    private String quoteRating;

    @Override
    public String toString() {
        return "Quote{" +
                "quoteId='" + quoteId + '\'' +
                ", quoteText='" + quoteText + '\'' +
                ", quoteLang='" + quoteLang + '\'' +
                ", quoteWriter='" + quoteWriter + '\'' +
                ", quoteLikes='" + quoteLikes + '\'' +
                ", quoteRating='" + quoteRating + '\'' +
                '}';
    }

    public Quote(String quoteId, String quoteText, String quoteLang, String quoteWriter, String quoteLikes, String quoteRating) {
        this.quoteId = quoteId;
        this.quoteText = quoteText;
        this.quoteLang = quoteLang;
        this.quoteWriter = quoteWriter;
        this.quoteLikes = quoteLikes;
        this.quoteRating = quoteRating;
    }

    public String getQuoteId() {
        return quoteId;
    }

    public void setQuoteId(String quoteId) {
        this.quoteId = quoteId;
    }

    public String getQuoteText() {
        return quoteText;
    }

    public void setQuoteText(String quoteText) {
        this.quoteText = quoteText;
    }

    public String getQuoteLang() {
        return quoteLang;
    }

    public void setQuoteLang(String quoteLang) {
        this.quoteLang = quoteLang;
    }

    public String getQuoteWriter() {
        return quoteWriter;
    }

    public void setQuoteWriter(String quoteWriter) {
        this.quoteWriter = quoteWriter;
    }

    public String getQuoteLikes() {
        return quoteLikes;
    }

    public void setQuoteLikes(String quoteLikes) {
        this.quoteLikes = quoteLikes;
    }

    public String getQuoteRating() {
        return quoteRating;
    }

    public void setQuoteRating(String quoteRating) {
        this.quoteRating = quoteRating;
    }
}
