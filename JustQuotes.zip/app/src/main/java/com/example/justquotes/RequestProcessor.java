package com.example.justquotes;
import android.app.ProgressDialog;
import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;


public class RequestProcessor extends AsyncTask<String, String, String> {
    private String resp;
    private ProgressDialog progressDialog;
    private MainActivity mainActivity;

    public RequestProcessor(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    public String getData() {
        return this.resp;
    }

    @Override
    protected String doInBackground(String... uri) {

        StringBuffer response = new StringBuffer();
// Create connection
        try {
            // Create URL
            URL githubEndpoint = new URL(uri[0]);
            HttpsURLConnection con =
                    (HttpsURLConnection) githubEndpoint.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();
            System.out.println("Resposse code : "+responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) { // success
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        con.getInputStream()));
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                //convert into POJO
                processResponse(response.toString());
            } else {
                System.out.println("GET request not worked");
            }
            con.disconnect();
            //JSON PARSING ENDS

        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return response.toString();
    }

    @Override
    protected void onPostExecute(String result) {
        //Do anything with response.
        resp = result;
        this.mainActivity.buildFrame();
        progressDialog.dismiss();
    }

    @Override
    protected void onPreExecute() {
        progressDialog = new ProgressDialog(this.mainActivity);
        progressDialog.setMax(100);
        progressDialog.setMessage("Getting data....");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
    }

    private void processResponse(String response){
        try{
            //JSONObject jsonObject = new JSONObject(response);
            JSONArray jsonArray = new JSONArray(response);

            for(int i = 0;i<jsonArray.length();i++){
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                Quote quote = new Quote(jsonObject.getString("_id"),
                                        jsonObject.getString("en"),"en",
                                        jsonObject.getString("author"),
                                        (jsonObject.has("numberOfVotes"))?jsonObject.getString("numberOfVotes"):"0",
                                        (jsonObject.has("rating"))?jsonObject.getString("rating"):"0");
                this.mainActivity.quotes.add(quote);
            }
        }catch (Exception e){
            System.out.println("Error parsing response in method processResponse "+e.getMessage());
        }
    }
}
