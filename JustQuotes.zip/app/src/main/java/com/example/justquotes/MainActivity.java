package com.example.justquotes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.wenchao.cardstack.CardStack;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CardStack.CardEventListener{

    List<Quote> quotes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init(){
        quotes = new ArrayList<Quote>();
        RequestProcessor requestProcessor = new RequestProcessor(this);
        requestProcessor.execute("https://programming-quotes-api.herokuapp.com/quotes/");
    }

    public void buildFrame(){
        //CardView cardView = (CardView)findViewById(R.id.card_view);
        CardStack cardStack = (CardStack) findViewById(R.id.container);
        cardStack.setAdapter(new QuotesAdaptor(this,R.layout.list_item_view,this.quotes));
        cardStack.setStackMargin(20);
        cardStack.setListener(this);
    }

    @Override
    public boolean swipeEnd(int direction, float distance) {
        //if "return true" the dismiss animation will be triggered
        //if false, the card will move back to stack
        //distance is finger swipe distance in dp

        //the direction indicate swipe direction
        //there are four directions
        //  0  |  1
        // ----------
        //  2  |  3
        System.out.println("swipeEnd");
        return true;
    }

    @Override
    public boolean swipeStart(int i, float v) {
        System.out.println("swipeStart");
        return true;
    }

    @Override
    public boolean swipeContinue(int i, float v, float v1) {
        System.out.println("swipeContinue");
        return true;
    }

    @Override
    public void discarded(int i, int i1) {

    }

    @Override
    public void topCardTapped() {
        System.out.println("topCardTapped");
    }


    class QuotesAdaptor extends ArrayAdapter<Quote>{
        List<Quote> quotes;
        //activity context
        Context context;
        //the layout resource file for the list items
        int resource;
        //dir
        final File dir;

        public QuotesAdaptor(Context context,int resource, List<Quote> quotes){
            super(context, resource, quotes);
            this.context = context;
            this.quotes =quotes;
            this.resource = resource;
            this.dir = ScreenshotUtils.getMainDirectoryName(this.context);
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            //getting the view
            View view = layoutInflater.inflate(resource, null, false);
            TextView quoteText = (TextView) view.findViewById(R.id.quoteText);
            TextView quoteAuthor = (TextView) view.findViewById(R.id.quoteAuthor);

            quoteText.setText(this.quotes.get(position).getQuoteText());
            quoteAuthor.setText(this.quotes.get(position).getQuoteWriter());
            //for clipboard
            final String quoteTextString = this.quotes.get(position).getQuoteText() +"\n\n\n - " + this.quotes.get(position).getQuoteWriter();
            ImageButton clipBoard = (ImageButton)view.findViewById(R.id.clipboard);
            clipBoard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    android.content.ClipboardManager clipboardManager = (android.content.ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                    android.content.ClipData clipData = android.content.ClipData.newPlainText("Quote",quoteTextString);
                    clipboardManager.setPrimaryClip(clipData);
                    Toast.makeText(getApplicationContext(),"Copied to Clipboard!\n\n"+quoteTextString , Toast.LENGTH_SHORT).show();
                }
            });

            //for download
            final String fileName = "JustQuote"+position+".png";

            ImageButton download = (ImageButton)view.findViewById(R.id.download);
            download.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),"Saving... ", Toast.LENGTH_SHORT).show();
                    File file = ScreenshotUtils.store(ScreenshotUtils.getScreenShot(v),fileName,dir);
                    Toast.makeText(getApplicationContext(),"Saved as "+file.getName()+" at "+file.getAbsolutePath(), Toast.LENGTH_SHORT).show();
                }
            });

            //for share
            ImageButton share = (ImageButton)view.findViewById(R.id.share);
            share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),"Share to..." , Toast.LENGTH_SHORT).show();
                    Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    String shareBody = quoteTextString;
                    String shareSub = "Just Quote";
                    sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                    sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "Share using"));
                }
            });

            return view;
        }
    }
}
